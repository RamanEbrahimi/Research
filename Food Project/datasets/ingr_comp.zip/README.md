# Issues

## An issue with Farnesol (2017-11-16)

It was discovered by Augustine Koh <ak.augustine.koh@gmail.com> and Lav
Varshney <varshney@illinois.edu> that "Farnesol", a flavor compound, is present
both as an ingredient (id: 339) and compound (id: 951). This may cause an issue
such as creating a self-loop. Thus, you may want to remove farnesol from the
ingredient list and from the ingredient-compound network. 

